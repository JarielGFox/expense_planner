import Expenses from "./components/Expenses";

function App() {



  return (
    // creare un componente custom EXPENSES e conterrà questa porzione di codice
    <div>
      <Expenses />
    </div>
  );
}

export default App;
